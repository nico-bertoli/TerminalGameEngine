#pragma once

struct vector2_int
{
    int X;
    int Y;
    vector2_int(int x, int y):X(x),Y(y){}
};